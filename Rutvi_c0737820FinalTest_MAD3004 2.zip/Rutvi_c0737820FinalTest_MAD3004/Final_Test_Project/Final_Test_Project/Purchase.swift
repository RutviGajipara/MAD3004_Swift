//
//  Purchase.swift
//  Final_Test_Project
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
typealias purchasedItem = (artID : String,art : Art,quantity: Int)
class Purchase
{
    var purchaseID : String
    var purchaseDate : Date
    var orderedItem : [purchasedItem]
    var dataHelper = DataHelper()
    
    init()
    {
        self.purchaseID = ""
        self.purchaseDate = DateFormatter().date(from: "")!
        self.orderedItem = []
    }
    
    var PurchaseID : String
    {
        get{ return self.purchaseID}
        set { self.purchaseID = newValue}
    }
    
    
    var PurchasedDate : Date
    {
        get { return self.purchaseDate}
        set{ self.purchaseDate = newValue}
    }
    var Totalamount : Double?
    {
        get
        {
            var amount = 0.0
            if !self.orderedItem.isEmpty
            {
                for(_,art, qty) in self.orderedItem
                {
                    amount += art.price * (Double)(qty)
                }
            }
            return amount
        }
    }
    func displayData() -> String
    {
        var returnData = ""
        
        returnData += "\n Purchase ID : \(self.PurchaseID)"
        returnData += "\n Purchase Date : \(self.PurchasedDate)"
        returnData += "\n Item List : "
        if !self.orderedItem.isEmpty
        {
            for(_, product,qty) in self.orderedItem
            {
                returnData += "\n \tItem : \(product.display())"
                returnData += "\n \tQuantity : \(qty)"
            }
        }
        else
        {
            returnData += "\n No Item in the purchase list."
        }
        returnData += "\n Amount : \(String(describing: self.Totalamount))"
        return returnData
    }
    
    func buyItem()
    {
        dataHelper.allArts()
        print("Please Enter Art ID to choose any art piece from the list : ")
        let selectedArtID : String = readLine()!
        if let selectedArt = dataHelper.searchItem(artID: selectedArtID)
        {
            self.PurchaseID = selectedArtID
            self.PurchasedDate = Date()
            print("Enter Quanity : ")
            let qty : Int = (Int)(readLine()!)! 
            self.orderedItem += [(artID : selectedArtID,art : selectedArt, quantity : qty)]
        }
        else
        {
            print("Sorry..The ID you entered is unavailable.")
        }
    }
  
}
