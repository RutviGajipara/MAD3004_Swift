//
//  Book.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class Art : Artist,IDisplay{
    
    
    
     var artID: String
     var title : String
     var category : ArtCategory
     var price : Double
    
    override init(){
        self.artID = ""
        self.title = ""
        self.category = ArtCategory.None
        self.price = 0.0
         super.init()
    }
    
    init(artID: String, title: String, category: ArtCategory, price: Double, artistID: String, name: String, country: String){
        self.artID = artID
        self.title = title
        self.category = category
        self.price = price
        super.init(artistID: artistID, name: name, country: country)
    }
    func display() -> String
    {
        
        var returnData = ""
        
        returnData += "\t \(self.artID ?? "") ------ \(self.title ?? "") ------ \(self.category ?? ArtCategory.None) ------ \(self.price ?? 0.0)"
        return returnData
    }
}
