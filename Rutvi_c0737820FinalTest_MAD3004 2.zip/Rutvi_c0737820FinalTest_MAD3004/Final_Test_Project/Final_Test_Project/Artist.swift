//
//  Author.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class Artist  {
    var artistID: String
    var name : String
    var country : String
    
    init(){
        self.artistID = ""
        self.name = ""
        self.country = ""
    }
    
    init(artistID: String, name: String, country: String){
        self.artistID = artistID
        self.name = name
        self.country = country
    }
}
