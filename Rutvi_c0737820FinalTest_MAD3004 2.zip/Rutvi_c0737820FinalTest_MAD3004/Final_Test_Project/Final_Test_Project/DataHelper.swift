//
//  DataHelper.swift
//  Final_Test_Project
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper
{
    var ArtList = [String : Art]()
    var CustomerList = [String : Customer]()
    var custom = Customer()

    init()
    {
        self.loadArtData()
        self.loadCustomerData()
    }
    func loadArtData()
    {
        ArtList = [:]
        do
        {
            let painting = try Art(artID: "P101", title:"Mona Lisa", category: ArtCategory.Painting, price: 100.00, artistID: "PA101", name: "Leonardo da Vinci", country: "Italy")
            ArtList[(painting.artID)] = painting
            
            let photograph = try Art(artID: "P102", title: "Afghan Girl", category: ArtCategory.Photograph, price: 150.00, artistID: "PA102", name: "Steve McCuury", country: "America")
            ArtList[(photograph.artID)] = photograph
            
            let sculpture = try Art(artID: "S103", title: "Guitar", category: ArtCategory.Skuplture, price: 200.00, artistID: "SA103", name: "Pablo Picasso", country: "Spain")
            ArtList[(sculpture.artID)] = sculpture
            
            let drawing = try Art(artID: "D104", title: "Starry Nights", category: ArtCategory.Drawing, price: 100.00, artistID: "DA104", name: "Vincent Van Gogh", country: "Russia")
            ArtList[(drawing.artID)] = drawing
            
            let tiara = try Art(artID: "T105", title: "Diamond Tiara", category: ArtCategory.Antiques, price: 500.00, artistID: "TA105", name: "Napoleon 3", country: "France")
            ArtList[(tiara.artID)] = tiara
        }
        catch
        {
            print("Error : \(error)")
        }
    }
    
    func loadCustomerData()
    {
        CustomerList = [:]
        do
        {
            let cust1 = try Customer(customerID: "C101", name: "Michel", address: "Toronto", contactNo: "45678912", password: "michel11")
            CustomerList[(cust1.customerID)] = cust1
            
            let cust2 = try Customer(customerID: "C102", name: "Mira", address: "Windsor", contactNo: "56789843", password: "mira22")
            CustomerList[(cust2.customerID)] = cust2
        }
    }
    
    func allArts()
    {
        print("Art List : ")
        Util.drawLine()
        print("\t ID \t\t Title \t\t\t Category \t\t\t Price \t\t\t Artist ID \t\t\t Artist Name \t\t\t Country")
        for(_, value) in self.ArtList.sorted(by: { $0.key < $1.key })
        {
            Util.drawLine()
            print("\t \(value.artID)  ---- \(value.title) ---- \(value.category) ---- \(value.price) ---- \(value.artistID) ---- \(value.name) ---- \(value.country)")
        }
        Util.drawLine()
    }
    
    func searchItem(artID : String) -> Art?
    {
        if ArtList[artID] != nil
        {
            return ArtList[artID]! as Art
        }
        else
        {
            return nil
        }
    }
    
    func varifyUser(customerID : String, password : String) -> Int
    {
        if customerID == cust.name && password == cust.password
        {
            return choice
        }
        else
        {
            print("Invalid User...")
            return 0
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
