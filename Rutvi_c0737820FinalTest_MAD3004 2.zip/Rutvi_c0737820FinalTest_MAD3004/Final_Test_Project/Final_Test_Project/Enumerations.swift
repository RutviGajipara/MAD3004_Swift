//
//  Enumerations.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
enum ArtCategory : Int, CaseIterable{
    case Painting = 1
    case Photograph = 2
    case Skuplture = 3
    case Drawing = 4
    case Antiques = 5
    case None = 6
}

extension CaseIterable where Self: Hashable {
    static var allCases: [Self] {
        return [Self](AnySequence { () -> AnyIterator<Self> in
            var raw = 0
            var first: Self?
            return AnyIterator {
                let current = withUnsafeBytes(of: &raw) { $0.load(as: Self.self) }
                if raw == 0 {
                    first = current
                } else if current == first {
                    return nil
                }
                raw += 1
                return current
            }
        })
    }
}

protocol IDisplay{
    func display() -> String
}

protocol CaseIterable {
    associatedtype AllCases: Collection where AllCases.Element == Self
    static var allCases: AllCases { get }
}

