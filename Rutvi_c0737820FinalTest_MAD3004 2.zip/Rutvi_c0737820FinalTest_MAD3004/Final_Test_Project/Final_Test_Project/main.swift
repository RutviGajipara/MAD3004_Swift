//
//  main.swift
//  Final_Test_Project
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
var cust = Customer()
cust.userdata()
var artList = DataHelper()
artList.varifyUser(customerID: "", password: "")
var order = Purchase()
var choice = 1
while choice != 4{
    print("\n----What would you like to do today !----")
    print("\t 1 : Show Arts List ")
    print("\t 2 : Purchase Art ")
    print("\t 3 : Show Purchased Arts ")
    print("\t 4 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        print(artList.allArts())
    case 2:
        print(order.buyItem())
    case 3:
        print(order.displayData())
    case 4:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}


