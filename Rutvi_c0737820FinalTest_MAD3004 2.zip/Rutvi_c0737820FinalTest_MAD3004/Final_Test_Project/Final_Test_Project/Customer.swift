//
//  User.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class Customer{
      var customerID: String
      var name : String
      var address : String
      var contactNo : String
      var password : String
    
    init(){
        self.customerID = ""
        self.name = ""
        self.address = ""
        self.contactNo = ""
        self.password = ""
    }
    
    init(customerID: String, name: String, address: String, contactNo: String, password: String){
        self.customerID = customerID
        self.name = name
        self.address = address
        self.contactNo = contactNo
        self.password = password
    }
    var CustomerName : String
    {
        get{ return self.name}
        set {self.name = newValue}
    }
    var CustPassword : String
    {
        get { return self.password}
        set {self.password = newValue}
    }
    func userdata()
    {
        print("Enter your name : ")
        self.name = readLine()!
        print("Enter Password : ")
        self.password = readLine()!
    }
    
}
