//
//  ReservationClass.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias Reserve = (flight_id : String ,flight_schedule_date : String)
class Reservation : IDisplay
{
     var reservationId : String
     var reservationdate : Date
     var reservationSeatNo : String
     var reservationStatus : reservationStatusList
     var reservatonMealType : MealtypeList
    var reserve_flight : [Reserve]
    var flt = FlightClass()
    var pass = Passenger()
    var dataHelper = DataHelper()
    var selectedFlightClass: FlightClassList
    var Amount : Double
    {
        get{
            switch selectedFlightClass {
            case .Business:
                 return flt.baseFare! * 2
            case .Economy:
                return flt.baseFare!
            case .First_Class:
                return flt.baseFare! * 3
            default:
                return 0.0
            }
        }
    }
    
    init()
    {
        self.reservationId = ""
        self.reservationdate = Date()
        self.reservationSeatNo = ""
        self.reservationStatus = reservationStatusList.NoFlight
        self.reservatonMealType = MealtypeList.None
        self.reserve_flight = []
        self.selectedFlightClass = FlightClassList.None
     
    }
    
    init(reservationId : String, reservationdate : Date, reservationSeatNo : String,reservationStatus : reservationStatusList, reservatonMealType : MealtypeList , reserve_flight : [Reserve], Amount : Double, selectedFlightClass : FlightClassList)
    {
        self.reservationId = reservationId
        self.reservationdate = reservationdate
        self.reservationSeatNo = reservationSeatNo
        self.reservationStatus = reservationStatus
        self.reservatonMealType = reservatonMealType
        self.reserve_flight = reserve_flight
        self.selectedFlightClass = selectedFlightClass
    }
    
    var ReservationID : String
    {
        get{ return self.reservationId}
        set{ self.reservationId = newValue}
    }
    
    var ReservationDate: Date
    {
        get{ return self.reservationdate}
        set{ self.reservationdate = newValue}
    }
    
    var ReservationSeatNo: String
    {
        get{ return self.reservationSeatNo}
        set{ self.reservationSeatNo = newValue}
    }
    
    var ReservationStatus : reservationStatusList
    {
        get{ return self.reservationStatus ?? reservationStatusList.NoFlight}
        set{ self.reservationStatus = newValue}
    }
    
    var ReservationMealType : MealtypeList
    {
        get{ return self.reservatonMealType}
        set{ self.reservatonMealType = newValue}
    }
//    var TotalAmount : Double?
//    {
//    get{
//    var Total : Double?
//    let VegMeal : Double = 100.00
//    let NonVeg : Double = 150.00
//    let BaseFare : Double = 500.00
//
//
//    if (self.reservatonMealType.rawValue == MealtypeList.Veg.rawValue && flt.flight_class.rawValue == FlightClassList.Business.rawValue)
//    {
//    Total = VegMeal + (BaseFare * 3)
//    }
//    else if (self.reservatonMealType == MealtypeList.Veg && flt.flight_class == FlightClassList.First_Class)
//    {
//    Total = VegMeal + (BaseFare * 2)
//    }
//    else if (self.reservatonMealType == MealtypeList.Veg && flt.flight_class == FlightClassList.Economy)
//    {
//    Total = VegMeal + BaseFare
//    }
//    else if (self.reservatonMealType == MealtypeList.NonVeg && flt.flight_class == FlightClassList.Business)
//    {
//    Total = NonVeg + (BaseFare * 3)
//    }
//    else if (self.reservatonMealType == MealtypeList.NonVeg && flt.flight_class == FlightClassList.First_Class)
//    {
//    Total = NonVeg + (BaseFare * 2)
//    }
//    else if (self.reservatonMealType == MealtypeList.NonVeg && flt.flight_class == FlightClassList.Economy)
//    {
//    Total = NonVeg + BaseFare
//
//    }
//        return Total
//    }
//    }
    
    
    func displayData() -> String
    {
        var returnData = ""
        returnData += "\n Reservation Details : "
        returnData += "\n Reservation ID : \(self.reservationId)"
        print("Flight Details : ")
        returnData += flt.displayData()
        print("Passenger Details : ")
        returnData += pass.displayData()
        returnData += "\n Reservation Date : \(String(describing: self.reservationdate))"
        returnData += "\n  Reservation Status : \(self.reservationStatus )"
        returnData += "\n  MealType : \(self.reservatonMealType)"
        returnData += "\n  Class Type : \(self.selectedFlightClass)"
        returnData += "\n Seat Number : \(self.reservationSeatNo)"
        returnData += "\n Total Amount : \(self.Amount.asCurrency ?? 0.0.asCurrency)"
        return returnData
    }
    
    func selectClass() -> FlightClassList {
        print("Select class for the flight:")
        for fltCls in FlightClassList.allCases {
            print("Press \(fltCls.rawValue): for \(fltCls)")
        }
        let choice = (Int)(readLine()!)!
        return FlightClassList(rawValue: choice)!
    }
    
    func addFlight() 
    {
        
        func searchFlightFrom(source: AirportList, toDestination: AirportList) -> [FlightClass]? {
            var flights = [FlightClass]()
            for (_, flight) in dataHelper.flightList{
                if flight.flight_from == source && flight.flight_to == toDestination{
                    flights.append(flight)
                }
            }
            return flights
        }
        print("Enter flight ID to choose a flight from the list : ")
        let selectedFlightID : String = readLine()!
        
        if let selectedFlight = dataHelper.searchFLight(flight_id : selectedFlightID)
        {
            self.pass = Passenger().registerUser()
            self.reservationId = selectedFlightID
            self.reservationdate = Date()
            self.flt = selectedFlight
            self.selectedFlightClass = selectClass()
            self.reservationStatus = reservationStatusList.Confirmed
        }
        else
        {
            print("Sorry...A flight you needed is not available..!")
        }
    }
    func display()
    {
        print("Meal Type : ")
        for MealType in MealtypeList.allCases
        {
            print("Enter \(MealType.rawValue) for \(MealType)")
        }
        let choice = (Int)(readLine()!)
        self.reservatonMealType = MealtypeList(rawValue: choice!)!
        
}
    func  cancelReservation(){
            if !reserve_flight.isEmpty {
            print("Review your Flight \n \(self.displayData())")
            
            print("Please enter Flight ID to remove from the Reservation List : ")
            let selectedFlightID : String = readLine()!
            var flightIndex = -1
            
                for (index, var flight) in self.reserve_flight.enumerated() {
                if (flight.flight_id == selectedFlightID){
                    flightIndex = index
                }
            }
            
            if flightIndex != -1{
                self.reserve_flight.remove(at: flightIndex)
                print("The flight is cancelled")
            }
        }else{
            print("You have no flights to Travel")
        }
    }
    
    func availability()
    {
        var seatmap = [["A","B","C","D"],[1,2,3,4]]
        var row : [String]
        var seat : [Int]
        var booked  = ["A1","B2","C3","D4"]
        row = seatmap[0] as! [String]
        seat = seatmap[1] as! [Int]
        for i in 0..<row.count{
            for j in 0..<seat.count{
                var book: Bool = false
                for k in 0..<booked.count{
                    if booked[k].contains(row[i]+String(seat[j])){
                        book = true
                        break;
                    }else{
                        book = false
                    }
                }
                if book{
                    print("Booked Seat Number is : \(row[i])\(seat[j])")
                }else{
                    print("available seats are : \(row[i])\(seat[j])")
                }
            }
            print("New Row")
        }
        
        
    }
    
    func bookseat()
    {
        availability()
        print("Please enter seat No : ")
        let selectedSeatID : String = readLine()!
        self.reservationSeatNo = selectedSeatID
    }

        }
        

    

