//
//  FlightClass.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class FlightClass : IDisplay
{
    
     var flight_id : String
     var flight_from : AirportList
     var flight_to : AirportList
     var flight_airline_id : AirlineList
     var flight_schedule_date : String
     var flight_class : FlightClassList
     var flight_pilot_id : String
    var baseFare : Double?
     init()
    {
         self.flight_id = ""
        self.flight_from = AirportList.None
        self.flight_to = AirportList.None
        self.flight_airline_id = AirlineList.None
        self.flight_schedule_date = ""
        self.flight_class = FlightClassList.None
        self.flight_pilot_id = ""
        self.baseFare = 0.0
    }
    init(flight_id : String, flight_from : AirportList, flight_to : AirportList, flight_schedule_date : String, flight_airline_id : AirlineList, flight_class : FlightClassList ,flight_pilot_id : String, baseFare : Double)
    {
         self.flight_id = flight_id
        self.flight_from = flight_from
        self.flight_to = flight_to
          self.flight_airline_id = flight_airline_id
       self.flight_schedule_date = flight_schedule_date
      self.flight_class = flight_class
        self.flight_pilot_id = flight_pilot_id
        self.baseFare = baseFare
    }
    
        var FlightID : String
        {
            get{ return self.flight_id}
            set{ self.flight_id = newValue as! String}
        }
    var FlightFrom : AirportList
    {
        get{ return self.flight_from}
        set{ self.flight_from = newValue}
    }
    var FlightTo : AirportList
    {
        get{ return self.flight_to}
        set{ self.flight_to = newValue}
    }
    var FlightScheduleDate : String
    {
        get{ return self.flight_schedule_date}
        set{ self.flight_schedule_date = newValue}
    }
    var FlightAirlineID : AirlineList
    {
        get{ return self.flight_airline_id}
        set{ self.flight_airline_id = newValue}
    }
    
    var FlightClass : FlightClassList
    {
        get{ return self.flight_class}
        set{ self.flight_class = newValue}
    }
    
        var FlightPilotID : String
        {
            get{ return self.flight_pilot_id}
    
        }
    var BaseFare : Double?
    {
        get {return self.baseFare}
        set {self.baseFare = newValue}
    }
    func displayData() -> String
    {
        var returnData = ""
        returnData += "\n Flight ID : \(self.flight_id)"
        returnData += "\n Flight from : \(self.flight_from )"
        returnData += "\n Flight To : \(self.flight_to)"
         returnData += "\n  Date : \(self.flight_schedule_date)"
        returnData += "\n Airline Name : \(self.flight_airline_id)"
        returnData += "\n Flight Class : \(self.flight_class)"
        returnData += "\n Pilot ID : \(self.flight_pilot_id)"
       returnData += "\n Base Fare : \(self.baseFare?.asCurrency ?? 0.0.asCurrency)"
        return returnData
    }
    func display()
    {

        print("Depart From : ")
        for flightFrom in AirportList.allCases
        {
            print("Enter \(flightFrom.rawValue) for \(flightFrom)")
        }
        let choice = (Int)(readLine()!)
        self.flight_from = AirportList(rawValue: choice!)!

        print("Arrived to : ")
        for flightTo in AirportList.allCases
        {
            print("Enter \(flightTo.rawValue) for \(flightTo)")
        }
        let Choice = (Int)(readLine()!)
        self.flight_to = AirportList(rawValue: Choice!)!

        print("Airline Id : ")
        for AirlineId in AirlineList.allCases
        {
            print("Enter \(AirlineId.rawValue) for \(AirlineId)")
        }
        let Choice1 = (Int)(readLine()!)
        self.flight_airline_id = AirlineList(rawValue: Choice1!)!

        print("Flight Class : ")
        for Flightclass in FlightClassList.allCases
        {
            print("Enter \(Flightclass.rawValue) for \(Flightclass)")
        }
        let choice2 = (Int)(readLine()!)
        self.flight_class = FlightClassList(rawValue: choice2!)!

        print("Enter Date (in DD/MM/YYYY Format)")
         self.flight_schedule_date = readLine()!

        print("Enter Base Fare:")
        self.baseFare = (Double)(readLine()!)!
    }


        
    }

