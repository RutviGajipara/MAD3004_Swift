//
//  AirlineClass.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class AirLine
{
    private var airlines_id : Int?
    private var airlines_description : String?
    private var airlines_type : String?
    
    init()
    {
        self.airlines_id = 0
        self.airlines_description = ""
        self.airlines_type = ""
    }
    init(airlines_id : Int, airlines_description : String, airlines_type : String)
    {
        self.airlines_id = airlines_id
        self.airlines_description = airlines_description
        self.airlines_type = airlines_type
    }
    
    var AirlineID : Int?
    {
        get{ return self.AirlineID}
        set{ self.airlines_id = newValue}
    }
    var AirlineDescriptin : String?
    {
        get{ return self.AirlineDescriptin}
        set{ self.airlines_description = newValue}
    }
    var AirLineType : String?
    {
        get{ return self.AirLineType}
        set{ self.airlines_type = newValue}
    }
    
}
