//
//  Extensions.swift
//  ARFinal
//
//  Created by Govinda Sharma on 2018-08-02.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

extension Double{
    var asCurrency: String{
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(for: self)!
    }
}
