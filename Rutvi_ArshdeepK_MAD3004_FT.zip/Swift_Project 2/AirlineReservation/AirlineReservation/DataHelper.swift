//
//  DataHelper.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper
{
    var flightList = [String : FlightClass]()
     var allMatchedFlights = [FlightClass]()
    var admins = [String]()
    init()
    {
        self.loadFlight()
    }
    
        func loadFlight()
    {
        flightList = [:]
        do{
            let flight1 = FlightClass(flight_id : "A101", flight_from : AirportList.Toronto_Pearson_Airport_Toronto, flight_to : AirportList.Indira_Gandhi_International_Airport_Delhi, flight_schedule_date : "09/12/2019", flight_airline_id: AirlineList.AirCanada, flight_class: FlightClassList.Business,flight_pilot_id : "P101", baseFare : 500.00)
            flightList[flight1.flight_id] = flight1

        let flight2 = FlightClass(flight_id : "A102", flight_from : AirportList.Chhatrapati_Shivaji_International_Airport_Mumbai, flight_to : AirportList.Charles_de_Gaulle_Airport_Paris, flight_schedule_date : "10/12/2019", flight_airline_id: AirlineList.AirFrance, flight_class: FlightClassList.Economy,flight_pilot_id : "P102", baseFare : 450.00)
            flightList[flight2.flight_id] = flight2

        let flight3 = FlightClass(flight_id : "A103", flight_from : AirportList.Chhatrapati_Shivaji_International_Airport_Mumbai, flight_to : AirportList.Heathrow_Airport_London, flight_schedule_date : "12/12/2019", flight_airline_id: AirlineList.AirIndia, flight_class: FlightClassList.First_Class,flight_pilot_id : "P103", baseFare : 700.00)
            flightList[flight3.flight_id] = flight3

        let flight4 = FlightClass(flight_id : "A104", flight_from : AirportList.Indira_Gandhi_International_Airport_Delhi, flight_to : AirportList.Toronto_Pearson_Airport_Toronto, flight_schedule_date : "08/08/2019", flight_airline_id: AirlineList.AirCanada, flight_class: FlightClassList.Economy,flight_pilot_id : "P104", baseFare : 670.00)
        flightList[flight4.flight_id] = flight4

        let flight5 = FlightClass(flight_id : "A105", flight_from : AirportList.Chhatrapati_Shivaji_International_Airport_Mumbai, flight_to : AirportList.Indira_Gandhi_International_Airport_Delhi, flight_schedule_date : "15/08/2019", flight_airline_id: AirlineList.AirIndia, flight_class: FlightClassList.Economy,flight_pilot_id : "P105", baseFare : 800.00)
        flightList[flight5.flight_id] = flight5
        
        let flight6 = FlightClass(flight_id : "A106", flight_from : AirportList.Indira_Gandhi_International_Airport_Delhi, flight_to : AirportList.Heathrow_Airport_London, flight_schedule_date : "25/08/2019", flight_airline_id: AirlineList.AirIndia, flight_class: FlightClassList.First_Class,flight_pilot_id : "P105", baseFare : 230.00)
        flightList[flight6.flight_id] = flight6
        
        let flight7 = FlightClass(flight_id : "A107", flight_from : AirportList.Toronto_Pearson_Airport_Toronto, flight_to : AirportList.Heathrow_Airport_London, flight_schedule_date : "31/08/2019", flight_airline_id: AirlineList.AirIndia, flight_class: FlightClassList.Economy,flight_pilot_id : "P107", baseFare : 500.00)
        flightList[flight7.flight_id] = flight7
        
        let flight8 = FlightClass(flight_id : "A108", flight_from : AirportList.Toronto_Pearson_Airport_Toronto, flight_to : AirportList.Charles_de_Gaulle_Airport_Paris, flight_schedule_date : "09/09/2019", flight_airline_id: AirlineList.AirIndia, flight_class: FlightClassList.Business,flight_pilot_id : "P108", baseFare : 400.00)
        flightList[flight8.flight_id] = flight8
        
    }catch
    {
        print("Error: \(error)")
        }
    }
    
    
    func allflight()
    {
        print("Flight details")
        Util.drawLine()
        print("\t Flight ID \t\t Flight from \t\t Flight To \t\t Flight Schedule Date \t\t Flight Airline ID \t\t Flight Class \t\t Flight Pilot ID")
        Util.drawLine()
        for (_, value) in self.flightList.sorted(by: {$0.key < $1.key })
        {
            
            print("\t \(value.FlightID) --- \(value.FlightFrom) --- \(value.FlightTo) --- \(value.FlightAirlineID) --- \(value.FlightScheduleDate) --- \(value.FlightClass) --- \(value.FlightPilotID))")
        }
        Util.drawLine()
    }
    
//    func searchFlightFrom(source: AirportList) -> [FlightClass]? {
//        var flights = [FlightClass]()
//        for (_, flight) in flightList{
//            if flight.flight_from == source{
//                flights.append(flight)
//            }
//        }
//        return flights
//    }
    
    func searchFlightFrom(source: AirportList, toDestination: AirportList) -> [FlightClass]? {
        var flights = [FlightClass]()
        for (_, flight) in flightList{
            if flight.flight_from == source && flight.flight_to == toDestination{
                flights.append(flight)
            }
        }
        return flights
    }
    
    func searchFLight(flight_id : String) -> FlightClass?
    {
        if flightList[flight_id] != nil
        {
            return flightList[flight_id]! as FlightClass
        }
        else
        {
            print("Flight is not Available")
            return nil
        }
    }
    func displayFlights() {
//        for (_,flight) in flightList{
//            print("\(flight.displayData())")
//
//        }
          print((allMatchedFlights) as Any)
    }
       
    

}
