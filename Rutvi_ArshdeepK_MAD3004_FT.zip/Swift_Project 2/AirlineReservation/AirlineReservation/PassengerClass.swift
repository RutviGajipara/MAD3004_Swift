//
//  PassengerClass.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Passenger
{
     var passenger_id : String
     var passenger_passport_no : String
     var passenger_name : String
     var passenger_mobile : Int
     var passenger_email : String
     var passenger_address : String
     var passenger_birthdate : String
     //var cost : Int?
    
    init()
    {
       self.passenger_id = ""
       self.passenger_passport_no = ""
        self.passenger_name = ""
       self.passenger_mobile = 0
        self.passenger_email = ""
        self.passenger_address = ""
        self.passenger_birthdate = ""
    }
    init(passenger_id : String, passenger_passport_no : String, passenger_name : String,passenger_mobile : Int, passenger_email : String, passenger_address : String,passenger_birthdate : String)
    {
        self.passenger_id = passenger_id
        self.passenger_passport_no = passenger_passport_no
        self.passenger_name = passenger_name
        self.passenger_mobile = passenger_mobile
        self.passenger_email = passenger_email
        self.passenger_address = passenger_address
        self.passenger_birthdate = passenger_birthdate
    }
    
    var PassengerID : String
    {
        get{ return self.passenger_id}
        set{ self.passenger_id = newValue}
    }
    var PassengerPassportNo : String
    {
        get{ return self.passenger_passport_no}
        set{ self.passenger_passport_no = newValue}
    }
    var PassengerName : String
    {
        get{ return self.passenger_name}
        set{ self.passenger_name = newValue}
    }
    var PassengerMobile : Int
    {
        get{ return self.passenger_mobile}
        set{ self.passenger_mobile = newValue}
    }
    var PassengerEmail : String
    {
        get{ return self.passenger_email}
        set{ self.passenger_email = newValue}
    }
    var PassengerAddress : String
    {
        get{ return self.passenger_address}
        set{ self.passenger_address = newValue}
    }
    var PassengerBirthdate : String
    {
        get{ return self.passenger_birthdate}
        set{ self.passenger_birthdate = newValue}
    }
    
    func displayData() -> String{
        var returnData = ""
            returnData += " Passenger ID : \(self.passenger_id)"
            returnData += "\n Passport Number: \(self.passenger_passport_no)"
            returnData += "\n Passnger Name :\(self.passenger_name)"
            returnData += "\n Mobile Number : \(self.passenger_mobile)"
            returnData += "\n Email : \(self.PassengerEmail)"
            returnData += "\n Passenger Address : \(self.PassengerAddress)"
            returnData += "\n Passenger Date of Birth : \(self.PassengerBirthdate)"
        
        return returnData
    }
    
    func registerUser() -> Passenger{
        print("Enter Passenger ID : ")
        self.passenger_id = readLine()!
        
        print("Enter Passport Number : ")
        self.passenger_passport_no = readLine()!
        
        print("Enter Passenger Name : ")
        self.passenger_name = readLine()!
        
        print("Enter Mobile Number : ")
        self.passenger_mobile = (Int)(readLine()!)!
        
        print("Enter Email Id : ")
        self.PassengerEmail = readLine()!
        
        print("Enter Passenger Address : ")
        self.PassengerAddress = readLine()!
        
        print("Enter Passenger Date Of Birth (DD/MM/YYYY): ")
        self.PassengerBirthdate = readLine()!
        return self
    }
    
    
        
//
//        
//        
//        
//        
//        
//        
//        
//        
//        
//    }
  }
