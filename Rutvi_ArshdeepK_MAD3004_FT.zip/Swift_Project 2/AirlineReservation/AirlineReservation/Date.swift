//
//  Date.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Date
{
     let dateFormatter = DateFormatter()
    func dateFormat()
    {
//         dateFormatter.dateFormat = "DD/MM/YYYY"
//        let enteredDate = dateFormatter.date(from: String?)
        
//        dateFormatter.dateFormat = "MM/dd/yyyy"
//        let dateFromString = dateFormatter.date(from: dateString)
    }
}
