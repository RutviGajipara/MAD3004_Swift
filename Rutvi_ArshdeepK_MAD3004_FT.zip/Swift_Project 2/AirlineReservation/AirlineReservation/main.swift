//
//  main.swift
//  AirlineReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var users = ["arsh":"kaur", "chaapli":"saali"]

func initialStep(){
    var choice = 1
    var data = DataHelper()
    var pass = Passenger()
    var reserve = Reservation()
    while choice != 3
    {
         print("-----------------------------------------")
        print("\n 1 : Browse all Flights.")
        print("\n 2. Search Flight.")
        print("\n 3. Book a Flight")
        print("\n 4. Exit.")
         print("-----------------------------------------")
        print("Enter you choice please : ")
        choice = (Int)(readLine()!)!

        switch choice
        {
        case 1:
            data.allflight()
        case 2:
            print("Please select the source from the following:")
            for air in AirportList.allCases {
                print("Press \(air.rawValue) for  \(air)")
            }
            var src = (Int)(readLine()!)!

            print("Please select the destination from the following:")
            for air in AirportList.allCases {
                print("Press \(air.rawValue) for  \(air)")
            }
            var dst = (Int)(readLine()!)!
            var flightSo:[FlightClass] = DataHelper().searchFlightFrom(source: AirportList(rawValue: src)!, toDestination: AirportList(rawValue: dst)!)!
            for flight in flightSo{
                print(flight.displayData())
            }
        case 3:
         reserve.addFlight()
         reserve.availability()
         reserve.bookseat()
            reserve.display()
            print(reserve.displayData())
        case 4:
            exit(0)
        default:
              print("Please enter valid menu option.")
        }
    }
}

func checkLoginCredentials(){
    if verifyAdmin(){
        initialStep()
    } else {
        checkLoginCredentials()
    }
}

func verifyAdmin() -> Bool {
    var userVerified = false
    print("Enter username:")
    let user = readLine()!
    print("Enter password:")
    let password = readLine()!
    if users[user] == nil {
        print("User doesn't exist")
    } else if users[user] == password {
        print("Login successful")
        userVerified = true
    } else {
        print("Incorrect username/password")
    }
    return userVerified
}

checkLoginCredentials()

//pass.availability()

//var arsh = FlightClass()
//print(arsh.display())
//print(arsh.displayData())
////var rutvi = DataHelper()
////rutvi.searchFlight()
////rutvi.displayFlights()
//

//print(seats.displayData())
//print(seats.availability())
//
//
//var rutvi = DataHelper()
//print(rutvi.allflight())
//
//
//
//var cancelflight = Reservation()
//print(cancelflight.addFlight())
//print(cancelflight.displayData())
//print(cancelflight.cancelReservation())
//
//print(cancelflight.displayData())

//print("Please select the source from the following:")
//for air in AirportList.allCases {
//    print("Press \(air.rawValue) for  \(air)")
//}
//var source = (Int)(readLine()!)!
//var flights:[FlightClass] = DataHelper().searchFlightFrom(source: AirportList(rawValue: source)!, toDestination: )!
//for flight in flights{
//    print(flight.displayData())
//}



